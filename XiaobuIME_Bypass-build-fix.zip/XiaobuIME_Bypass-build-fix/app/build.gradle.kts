plugins {
    id("com.android.application")
}

android {
    namespace = "com.keyboard.bypass"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.keyboard.bypass"
        minSdk = 26
        targetSdk = 34
        versionCode = 13
        versionName = "1.3"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    compileOnly("de.robv.android.xposed:api:82")
}
