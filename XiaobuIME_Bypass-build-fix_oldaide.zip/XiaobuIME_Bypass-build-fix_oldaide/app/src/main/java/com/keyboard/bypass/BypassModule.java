package com.keyboard.bypass;

import java.lang.reflect.Method;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

/**
 * Xiaobu IME Bypass
 *
 * 双通道绕过小布输入法 (com.oplus.keyboard)：
 *  1) 激活校验：强制 key_activate / storage.a 布尔方法返回 true
 *  2) 强制更新弹窗：拦截 AppUpdateManager.showAppStoreUpdateDialog 并压制 isForceUpdate
 *
 * 更新通道来自对 1.8.27.17 (versionName 16.14.4) 的分析：
 *  - com.oplus.keyboard.update.AppUpdateManager
 *  - com.oplus.keyboard.update.appstore.AppStoreUpdateManager
 *  - 字段 isForceUpdate / innerForceUpdate，方法 showAppStoreUpdateDialog
 */
public class BypassModule implements IXposedHookLoadPackage {

    private static final String TARGET_PKG = "com.oplus.keyboard";
    private static final String TAG = "[XB-Bypass]";

    @Override
    public void handleLoadPackage(LoadPackageParam lpparam) throws Throwable {
        if (!TARGET_PKG.equals(lpparam.packageName)) {
            return;
        }

        hookActivation(lpparam);
        hookForceUpdate(lpparam);
    }

    /** 通道1：激活校验 bypass（原逻辑） */
    private void hookActivation(LoadPackageParam lpparam) {
        try {
            XC_MethodHook storageHook = new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    for (Object arg : param.args) {
                        if ("key_activate".equals(arg)) {
                            param.setResult(true);
                            break;
                        }
                    }
                }
            };

            XposedHelpers.findAndHookMethod(
                "android.app.SharedPreferencesImpl", lpparam.classLoader, "getBoolean",
                String.class, boolean.class, storageHook
            );

            Class<?> storageClass = XposedHelpers.findClass("com.oplus.keyboard.utils.storage.a", lpparam.classLoader);
            for (Method m : storageClass.getDeclaredMethods()) {
                if (m.getReturnType() == boolean.class) {
                    XposedBridge.hookMethod(m, storageHook);
                }
            }
            XposedBridge.log(TAG + " [+] activation hooked: key_activate -> true");
        } catch (Throwable t) {
            XposedBridge.log(TAG + " [-] activation hook failure: " + t.getMessage());
        }
    }

    /** 通道2：强制更新弹窗 bypass（新增） */
    private void hookForceUpdate(LoadPackageParam lpparam) {
        // 2.1 拦截弹窗方法
        try {
            Class<?> aum = XposedHelpers.findClass("com.oplus.keyboard.update.AppUpdateManager", lpparam.classLoader);
            XposedBridge.hookAllMethods(aum, "showAppStoreUpdateDialog", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    XposedBridge.log(TAG + " [+] blocked showAppStoreUpdateDialog");
                    param.setResult(null);
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + " [-] showAppStoreUpdateDialog hook failure: " + t.getMessage());
        }

        // 2.2 压制 isForceUpdate / innerForceUpdate 字段与 getter
        suppressForceUpdate(lpparam, "com.oplus.keyboard.update.AppUpdateManager");
        suppressForceUpdate(lpparam, "com.oplus.keyboard.update.appstore.AppStoreUpdateManager");
    }

    private void suppressForceUpdate(LoadPackageParam lpparam, String clsName) {
        try {
            Class<?> cls = XposedHelpers.findClass(clsName, lpparam.classLoader);
            // 字段：仅处理实例字段，需按对象实例改；方法级更通用，先 hook getter
            for (Method m : cls.getDeclaredMethods()) {
                String mn = m.getName();
                if (m.getReturnType() == boolean.class &&
                    ("isForceUpdate".equals(mn) || "getForceUpdate".equals(mn)
                     || "getInnerForceUpdate".equals(mn) || "innerForceUpdate".equals(mn))) {
                    XposedBridge.hookMethod(m, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            param.setResult(false);
                        }
                    });
                }
            }
            XposedBridge.log(TAG + " [+] suppress forceUpdate on " + clsName);
        } catch (Throwable t) {
            XposedBridge.log(TAG + " [-] suppress forceUpdate failure on " + clsName + ": " + t.getMessage());
        }
    }
}
