# Xposed module: keep all Xposed API references
-keep class de.robv.android.xposed.** { *; }

# Keep the module entry point
-keep class com.keyboard.bypass.BypassModule { *; }